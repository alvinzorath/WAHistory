package com.example.wahistory;

import org.json.JSONObject;

/** Satu pesan atau satu catatan panggilan. */
public class Msg {
    public String id;
    public String chatKey;
    public String chat;
    public String sender;
    public String text;
    public long time;
    public boolean group;
    public int type; // 0 = pesan, 1 = panggilan

    public static String makeId(String chatKey, String sender, String text, long time) {
        return chatKey + "|" + sender + "|" + text + "|" + time;
    }

    public JSONObject toJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("k", chatKey);
        o.put("c", chat);
        o.put("s", sender);
        o.put("t", text);
        o.put("tm", time);
        o.put("g", group);
        o.put("ty", type);
        return o;
    }

    public static Msg fromJson(JSONObject o) {
        Msg m = new Msg();
        m.id = o.optString("id");
        m.chatKey = o.optString("k");
        m.chat = o.optString("c");
        m.sender = o.optString("s");
        m.text = o.optString("t");
        m.time = o.optLong("tm");
        m.group = o.optBoolean("g");
        m.type = o.optInt("ty");
        return m;
    }
}
