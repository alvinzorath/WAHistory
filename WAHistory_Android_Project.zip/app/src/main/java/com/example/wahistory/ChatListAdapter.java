package com.example.wahistory;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class ChatListAdapter extends BaseAdapter {
    public static class Row {
        public String key, title, preview;
        public long time;
        public boolean group, red;
    }

    private final Context context;
    private List<Row> rows = new ArrayList<>();

    public ChatListAdapter(Context context) { this.context = context; }

    public void setRows(List<Row> r) {
        rows = new ArrayList<>(r);
        notifyDataSetChanged();
    }

    @Override public int getCount() { return rows.size(); }
    @Override public Object getItem(int p) { return rows.get(p); }
    @Override public long getItemId(int p) { return p; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) v = LayoutInflater.from(context).inflate(R.layout.item_chat, parent, false);
        Row r = rows.get(position);
        ((ImageView) v.findViewById(R.id.avatar)).setImageBitmap(
            Avatars.get(context, r.key, r.title, UiUtil.dp(context, 52)));
        ((TextView) v.findViewById(R.id.name)).setText(r.title);
        ((TextView) v.findViewById(R.id.time)).setText(UiUtil.listTime(r.time));
        TextView pv = (TextView) v.findViewById(R.id.preview);
        pv.setText(r.preview);
        pv.setTextColor(r.red ? 0xFFD93025 : 0xFF667781);
        return v;
    }
}
