package com.example.wahistory;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.os.Environment;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Membaca folder .Statuses WhatsApp lewat akses folder (SAF) yang diizinkan pengguna. */
public class StatusRepo {
    public static class Item {
        public Uri uri;
        public String name, mime;
        public long modified;
        public boolean video;
    }

    private static final String[] COLS = {
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_LAST_MODIFIED
    };

    /**
     * Baca folder status WhatsApp langsung (butuh izin "Akses semua file").
     * @return daftar status, atau null bila tidak ada folder status yang bisa dibaca.
     */
    @SuppressWarnings("deprecation")
    public static List<Item> loadAuto() {
        File base = Environment.getExternalStorageDirectory();
        String[] rel = {
            "Android/media/com.whatsapp/WhatsApp/Media/.Statuses",
            "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses",
            "WhatsApp/Media/.Statuses",
            "WhatsApp Business/Media/.Statuses"
        };
        List<Item> out = new ArrayList<>();
        boolean found = false;
        for (String r : rel) {
            File[] files = new File(base, r).listFiles();
            if (files == null) continue;
            found = true;
            for (File f : files) {
                if (!f.isFile()) continue;
                String low = f.getName().toLowerCase(Locale.ROOT);
                boolean video = low.endsWith(".mp4") || low.endsWith(".3gp") || low.endsWith(".mkv");
                boolean image = low.endsWith(".jpg") || low.endsWith(".jpeg")
                    || low.endsWith(".png") || low.endsWith(".webp");
                if (!video && !image) continue;
                Item it = new Item();
                it.uri = Uri.fromFile(f);
                it.name = f.getName();
                it.mime = video ? "video/mp4" : "image/jpeg";
                it.video = video;
                it.modified = f.lastModified();
                out.add(it);
            }
        }
        if (!found) return null;
        Collections.sort(out, (a, b) -> Long.compare(b.modified, a.modified));
        return out;
    }

    /** @return daftar status, atau null bila folder tidak bisa dibaca. */
    public static List<Item> safeLoad(Context c, Uri tree) {
        try {
            return load(c, tree);
        } catch (Throwable t) {
            return null;
        }
    }

    private static List<Item> load(Context c, Uri tree) {
        String root = DocumentsContract.getTreeDocumentId(tree);
        String dir = findStatuses(c, tree, root, 0);
        if (dir == null) dir = root;
        List<Item> out = new ArrayList<>();
        for (String[] ch : children(c, tree, dir)) {
            String mime = ch[2] == null ? "" : ch[2];
            String name = ch[1] == null ? "" : ch[1];
            boolean video = isVideo(mime, name);
            boolean image = mime.startsWith("image/");
            if (!video && !image) continue;
            Item it = new Item();
            it.uri = DocumentsContract.buildDocumentUriUsingTree(tree, ch[0]);
            it.name = name;
            it.mime = mime;
            it.video = video;
            try { it.modified = Long.parseLong(ch[3]); } catch (Exception ignored) {}
            out.add(it);
        }
        Collections.sort(out, (a, b) -> Long.compare(b.modified, a.modified));
        return out;
    }

    public static boolean isVideo(String mime, String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        return (mime != null && mime.startsWith("video/"))
            || n.endsWith(".mp4") || n.endsWith(".3gp") || n.endsWith(".mkv");
    }

    private static List<String[]> children(Context c, Uri tree, String parentId) {
        List<String[]> out = new ArrayList<>();
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        try (Cursor cur = c.getContentResolver().query(childrenUri, COLS, null, null, null)) {
            if (cur == null) return out;
            while (cur.moveToNext()) {
                out.add(new String[] {
                    cur.getString(0), cur.getString(1), cur.getString(2),
                    String.valueOf(cur.getLong(3))
                });
            }
        }
        return out;
    }

    private static boolean isDir(String mime) {
        return DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);
    }

    /** Cari folder berisi media status, mulai dari folder yang dipilih. */
    private static String findStatuses(Context c, Uri tree, String parentId, int depth) {
        List<String[]> ch = children(c, tree, parentId);
        for (String[] x : ch) {
            String m = x[2] == null ? "" : x[2];
            if (m.startsWith("image/") || m.startsWith("video/")) return parentId;
        }
        for (String[] x : ch) {
            if (isDir(x[2]) && ".Statuses".equals(x[1])) return x[0];
        }
        if (depth < 4) {
            for (String[] x : ch) {
                if (!isDir(x[2]) || x[1] == null) continue;
                String n = x[1];
                if (n.equals("WhatsApp") || n.equals("Media") || n.equals("com.whatsapp")
                        || n.equals("com.whatsapp.w4b") || n.equals("WhatsApp Business")) {
                    String r = findStatuses(c, tree, x[0], depth + 1);
                    if (r != null) return r;
                }
            }
        }
        return null;
    }
}
