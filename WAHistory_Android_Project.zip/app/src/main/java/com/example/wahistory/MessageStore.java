package com.example.wahistory;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Penyimpanan lokal: satu baris JSON per pesan di filesDir/messages.jsonl. */
public class MessageStore {
    public interface Listener { void onChanged(); }

    private static final int MAX = 8000;
    private static final int TRIM = 1000;
    private static MessageStore instance;

    public static synchronized MessageStore get(Context c) {
        if (instance == null) instance = new MessageStore(c.getApplicationContext());
        return instance;
    }

    private final Context ctx;
    private final File file;
    private final List<Msg> all = new ArrayList<>();
    private final Set<String> ids = new HashSet<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile Listener listener;

    private MessageStore(Context c) {
        ctx = c;
        file = new File(c.getFilesDir(), "messages.jsonl");
        load();
    }

    public void setListener(Listener l) { listener = l; }

    private void notifyChanged() {
        final Listener l = listener;
        if (l != null) {
            main.post(new Runnable() { @Override public void run() { l.onChanged(); } });
        }
    }

    private void load() {
        try (BufferedReader r = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), "UTF-8"))) {
            String line;
            while ((line = r.readLine()) != null) {
                try {
                    Msg m = Msg.fromJson(new JSONObject(line));
                    if (m.id.isEmpty()) continue;
                    all.add(m);
                    ids.add(m.id);
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    private void append(Msg m) {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(file, true), "UTF-8")) {
            w.write(m.toJson().toString());
            w.write("\n");
        } catch (Exception ignored) {}
    }

    private void rewrite() {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(file, false), "UTF-8")) {
            for (Msg m : all) {
                w.write(m.toJson().toString());
                w.write("\n");
            }
        } catch (Exception ignored) {}
    }

    public static boolean isMissed(String text) {
        String t = text == null ? "" : text.toLowerCase(Locale.ROOT);
        return t.contains("tidak terjawab") || t.contains("missed");
    }

    /** @return true jika pesan baru disimpan (bukan duplikat). */
    public synchronized boolean add(Msg m, boolean fuzzy) {
        if (ids.contains(m.id)) return false;

        if (fuzzy) {
            long window = m.type == 1 ? 60000 : (m.dupWindow > 0 ? m.dupWindow : 4000);
            int checked = 0;
            for (int i = all.size() - 1; i >= 0 && checked < 120; i--, checked++) {
                Msg o = all.get(i);
                if (o.chatKey.equals(m.chatKey) && o.type == m.type
                        && o.text.equals(m.text) && Math.abs(m.time - o.time) < window) {
                    return false;
                }
            }
        }

        boolean needRewrite = false;
        if (m.type == 1 && isMissed(m.text)) {
            // "Panggilan masuk" yang berujung tak terjawab diganti satu catatan saja.
            int checked = 0;
            for (int i = all.size() - 1; i >= 0 && checked < 40; i--, checked++) {
                Msg o = all.get(i);
                if (o.type == 1 && o.chatKey.equals(m.chatKey) && !isMissed(o.text)
                        && m.time - o.time < 90000 && m.time >= o.time) {
                    all.remove(i);
                    ids.remove(o.id);
                    needRewrite = true;
                    break;
                }
            }
        }

        all.add(m);
        ids.add(m.id);

        if (all.size() > MAX) {
            for (int i = 0; i < TRIM && !all.isEmpty(); i++) ids.remove(all.remove(0).id);
            needRewrite = true;
        }
        if (needRewrite) rewrite(); else append(m);
        notifyChanged();
        return true;
    }

    /** Tandai pesan (dicari lewat waktu kirim) sebagai dihapus pengirim. */
    public synchronized boolean markDeleted(String chatKey, long time) {
        for (int i = all.size() - 1; i >= 0; i--) {
            Msg m = all.get(i);
            if (m.type == 0 && m.time == time && m.chatKey.equals(chatKey)) {
                if (m.deleted) return false;
                m.deleted = true;
                rewrite();
                notifyChanged();
                return true;
            }
        }
        return false;
    }

    public synchronized int size() { return all.size(); }

    public synchronized List<Chat> getChats(String query) {
        String q = query == null ? "" : query.toLowerCase(Locale.ROOT).trim();
        Map<String, Chat> map = new LinkedHashMap<>();
        for (Msg m : all) {
            if (m.type != 0) continue;
            Chat c = map.get(m.chatKey);
            if (c == null) {
                c = new Chat();
                c.key = m.chatKey;
                map.put(m.chatKey, c);
            }
            c.title = m.chat;
            c.group = m.group;
            c.count++;
            if (c.last == null || m.time >= c.last.time) c.last = m;
            if (!q.isEmpty() && m.text.toLowerCase(Locale.ROOT).contains(q)) {
                if (c.match == null || m.time >= c.match.time) c.match = m;
            }
        }
        List<Chat> out = new ArrayList<>();
        for (Chat c : map.values()) {
            if (q.isEmpty() || c.match != null
                    || c.title.toLowerCase(Locale.ROOT).contains(q)) {
                out.add(c);
            }
        }
        Collections.sort(out, (a, b) -> Long.compare(b.last.time, a.last.time));
        return out;
    }

    public synchronized List<Msg> getCalls(String query) {
        String q = query == null ? "" : query.toLowerCase(Locale.ROOT).trim();
        List<Msg> out = new ArrayList<>();
        for (int i = all.size() - 1; i >= 0; i--) {
            Msg m = all.get(i);
            if (m.type != 1) continue;
            if (q.isEmpty() || m.chat.toLowerCase(Locale.ROOT).contains(q)) out.add(m);
        }
        Collections.sort(out, (a, b) -> Long.compare(b.time, a.time));
        return out;
    }

    public synchronized List<Msg> getMessages(String chatKey) {
        List<Msg> out = new ArrayList<>();
        for (Msg m : all) {
            if (m.type == 0 && m.chatKey.equals(chatKey)) out.add(m);
        }
        Collections.sort(out, (a, b) -> Long.compare(a.time, b.time));
        return out;
    }

    public synchronized void deleteChat(String chatKey) {
        for (int i = all.size() - 1; i >= 0; i--) {
            Msg m = all.get(i);
            if (m.chatKey.equals(chatKey) && m.type == 0) {
                all.remove(i);
                ids.remove(m.id);
            }
        }
        rewrite();
        notifyChanged();
    }

    public synchronized void clearAll() {
        all.clear();
        ids.clear();
        rewrite();
        File[] avatars = Avatars.dir(ctx).listFiles();
        if (avatars != null) for (File f : avatars) f.delete();
        notifyChanged();
    }
}
