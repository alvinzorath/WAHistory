package com.example.wahistory;

/** Ringkasan satu percakapan untuk daftar chat. */
public class Chat {
    public String key;
    public String title;
    public boolean group;
    public Msg last;
    public Msg match; // pesan terbaru yang cocok dengan pencarian
    public int count;
}
