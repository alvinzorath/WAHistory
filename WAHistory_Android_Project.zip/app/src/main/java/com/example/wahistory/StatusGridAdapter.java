package com.example.wahistory;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.List;

public class StatusGridAdapter extends BaseAdapter {
    private final Context context;
    private List<StatusRepo.Item> items = new ArrayList<>();

    public StatusGridAdapter(Context c) { context = c; }

    public void set(List<StatusRepo.Item> n) {
        items = new ArrayList<>(n);
        notifyDataSetChanged();
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int p) { return items.get(p); }
    @Override public long getItemId(int p) { return p; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) v = LayoutInflater.from(context).inflate(R.layout.item_status, parent, false);
        StatusRepo.Item it = items.get(position);
        ThumbLoader.load(context, it.uri, (ImageView) v.findViewById(R.id.thumb));
        v.findViewById(R.id.play).setVisibility(it.video ? View.VISIBLE : View.GONE);
        return v;
    }
}
