package com.example.wahistory;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Catatan kejadian terbaru (tanpa isi pesan) untuk mencari tahu kenapa pesan terlewat. */
public class DebugLog {
    private static final List<String> lines = new ArrayList<>();

    public static synchronized void add(String s) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        lines.add(t + "  " + s);
        if (lines.size() > 60) lines.remove(0);
    }

    public static synchronized String dump() {
        if (lines.isEmpty()) return "(belum ada kejadian sejak aplikasi dibuka)";
        StringBuilder sb = new StringBuilder();
        for (int i = lines.size() - 1; i >= 0; i--) sb.append(lines.get(i)).append('\n');
        return sb.toString();
    }
}
