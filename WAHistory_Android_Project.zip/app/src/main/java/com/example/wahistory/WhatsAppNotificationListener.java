package com.example.wahistory;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.Person;
import android.content.ComponentName;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WhatsAppNotificationListener extends NotificationListenerService {

    private static final Pattern TITLE_COUNT =
        Pattern.compile("\\s*\\(\\d+\\s+(pesan|messages?)[^)]*\\)\\s*$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern GROUP_TEXT =
        Pattern.compile("^([^:\\n]{1,60}):\\s(.+)$", Pattern.DOTALL);
    private static final Pattern COUNT_ONLY =
        Pattern.compile("^\\d+\\s+(pesan|messages?).*$",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            handle(sbn);
        } catch (Throwable ignored) {
            // Jangan sampai service mati karena satu notifikasi aneh.
        }
    }

    @Override
    public void onListenerDisconnected() {
        // Sistem/pembersih RAM kadang memutus listener; minta sambung lagi.
        try {
            requestRebind(new ComponentName(this, WhatsAppNotificationListener.class));
        } catch (Throwable ignored) {}
    }

    private static String cs(CharSequence c) {
        return c == null ? "" : c.toString().trim();
    }

    private static String cleanTitle(String t) {
        return TITLE_COUNT.matcher(t).replaceAll("").trim();
    }

    private static boolean isGenericTitle(String t) {
        String l = t.toLowerCase(Locale.ROOT);
        return l.equals("whatsapp") || l.equals("whatsapp business");
    }

    private static boolean isJunk(String text) {
        String l = text.toLowerCase(Locale.ROOT);
        return l.contains("pesan ini telah dihapus")
            || l.contains("this message was deleted")
            || l.contains("memeriksa pesan baru")
            || l.contains("checking for new messages")
            || l.contains("whatsapp web sedang aktif")
            || l.contains("whatsapp web is currently active")
            || l.contains("pencadangan")
            || l.contains("backup in progress");
    }

    private void handle(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        boolean biz = "com.whatsapp.w4b".equals(pkg);
        if (!"com.whatsapp".equals(pkg) && !biz) return;

        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;

        Bundle e = n.extras;
        String title = cleanTitle(cs(e.getCharSequence(Notification.EXTRA_TITLE)));
        String conv = cleanTitle(cs(e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)));
        String text = cs(e.getCharSequence(Notification.EXTRA_TEXT));
        boolean group = e.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)
            || !conv.isEmpty();

        String chat = conv.isEmpty() ? title : conv;
        String oldStyleSender = null;
        if (conv.isEmpty()) {
            int at = title.indexOf(" @ ");
            if (at > 0) { // format lama: "Pengirim @ Grup"
                oldStyleSender = title.substring(0, at).trim();
                chat = cleanTitle(title.substring(at + 3));
                group = true;
            }
        }
        if (chat.isEmpty() || isGenericTitle(chat)) return;

        String chatKey = (biz ? "b|" : "w|") + chat.toLowerCase(Locale.ROOT);
        MessageStore store = MessageStore.get(this);
        boolean added = false;

        Parcelable[] cur = e.getParcelableArray(Notification.EXTRA_MESSAGES);
        Parcelable[] hist = e.getParcelableArray(Notification.EXTRA_HISTORIC_MESSAGES);
        boolean hasMessages = (cur != null && cur.length > 0) || (hist != null && hist.length > 0);

        String category = n.category;
        boolean call = Notification.CATEGORY_CALL.equals(category)
            || (!Notification.CATEGORY_MESSAGE.equals(category) && !hasMessages
                && text.length() < 60 && looksLikeCall(text));

        if (call) {
            String l = text.toLowerCase(Locale.ROOT);
            boolean wanted = MessageStore.isMissed(text)
                || l.contains("masuk") || l.contains("incoming");
            if (!wanted) return;
            Msg m = new Msg();
            m.chatKey = chatKey;
            m.chat = chat;
            m.sender = chat;
            m.text = text;
            m.time = sbn.getPostTime();
            m.group = group;
            m.type = 1;
            m.id = Msg.makeId(chatKey, chat, text, m.time);
            added = store.add(m, true);
        } else {
            List<Msg> list = new ArrayList<>();
            collect(hist, list, chatKey, chat, group, sbn.getPostTime());
            collect(cur, list, chatKey, chat, group, sbn.getPostTime());

            if (list.isEmpty()) {
                // Cadangan: notifikasi biasa tanpa MessagingStyle.
                if (text.isEmpty() || isJunk(text)) return;
                if (text.length() < 40 && COUNT_ONLY.matcher(text).matches()) return;
                String sender = group ? "" : chat;
                String body = text;
                if (group) {
                    if (oldStyleSender != null) {
                        sender = oldStyleSender;
                    } else {
                        Matcher gm = GROUP_TEXT.matcher(text);
                        if (gm.matches()) {
                            sender = gm.group(1).trim();
                            body = gm.group(2).trim();
                        }
                    }
                }
                list.add(build(chatKey, chat, group, sender, body, sbn.getPostTime(), true));
            }

            for (Msg m : list) {
                if (store.add(m, m.id.endsWith("|fuzzy"))) added = true;
            }
        }

        if (added) saveAvatar(n, chatKey, group);
    }

    private static boolean looksLikeCall(String text) {
        String l = text.toLowerCase(Locale.ROOT);
        return l.contains("panggilan") || l.contains("missed") || l.contains("voice call")
            || l.contains("video call") || l.contains("incoming");
    }

    private static Msg build(String chatKey, String chat, boolean group, String sender,
                             String text, long time, boolean fuzzy) {
        Msg m = new Msg();
        m.chatKey = chatKey;
        m.chat = chat;
        m.group = group;
        m.sender = sender;
        m.text = text;
        m.time = time;
        m.type = 0;
        m.id = Msg.makeId(chatKey, sender, text, time) + (fuzzy ? "|fuzzy" : "");
        return m;
    }

    private void collect(Parcelable[] arr, List<Msg> out, String chatKey, String chat,
                         boolean group, long postTime) {
        if (arr == null) return;
        for (Parcelable p : arr) {
            if (!(p instanceof Bundle)) continue;
            Bundle b = (Bundle) p;
            String text = cs(b.getCharSequence("text"));
            if (text.isEmpty() || isJunk(text)) continue;
            long tm = b.getLong("time", 0);
            String sender = senderOf(b);
            if (sender.isEmpty()) sender = group ? "" : chat;
            boolean fuzzy = tm <= 0;
            out.add(build(chatKey, chat, group, sender, text, fuzzy ? postTime : tm, fuzzy));
        }
    }

    private String senderOf(Bundle b) {
        String s = "";
        if (Build.VERSION.SDK_INT >= 28) s = personName(b);
        if (s.isEmpty()) s = cs(b.getCharSequence("sender"));
        return s;
    }

    @TargetApi(28)
    @SuppressWarnings("deprecation")
    private String personName(Bundle b) {
        Parcelable pp = b.getParcelable("sender_person");
        if (pp instanceof Person) return cs(((Person) pp).getName());
        return "";
    }

    private void saveAvatar(Notification n, String chatKey, boolean group) {
        try {
            // Foto grup tidak ditimpa supaya tidak berganti-ganti tiap pengirim.
            if (group && Avatars.exists(this, chatKey)) return;
            Icon ic = n.getLargeIcon();
            if (ic == null) return;
            Drawable d = ic.loadDrawable(this);
            if (d == null) return;
            Avatars.save(this, chatKey, Avatars.toBitmap(d));
        } catch (Throwable ignored) {}
    }
}
