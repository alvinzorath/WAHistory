package com.example.wahistory;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Bundle;
import android.text.TextUtils;

public class WhatsAppNotificationListener extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();

        // WhatsApp Messenger dan WhatsApp Business.
        if (!"com.whatsapp".equals(pkg) && !"com.whatsapp.w4b".equals(pkg)) {
            return;
        }

        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;

        Bundle e = n.extras;

        String title = e.getString(Notification.EXTRA_TITLE, "WhatsApp");
        CharSequence textCs = e.getCharSequence(Notification.EXTRA_TEXT);
        String text = textCs == null ? "" : textCs.toString().trim();

        // Group summary biasanya bukan pesan individual.
        boolean isGroupSummary =
            (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0;

        if (isGroupSummary || TextUtils.isEmpty(text)) return;

        // Jangan menyimpan notifikasi yang jelas-jelas bukan pesan.
        String lower = text.toLowerCase();
        if (lower.contains("pesan baru") && text.length() < 30) return;

        new HistoryStore(this).add(
            TextUtils.isEmpty(title) ? "WhatsApp" : title,
            text,
            System.currentTimeMillis()
        );
    }
}
