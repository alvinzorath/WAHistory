package com.example.wahistory;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.LruCache;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Locale;

public class Avatars {
    private static final int[] COLORS = {
        0xFF00A884, 0xFF1F7AB2, 0xFF6A5ACD, 0xFFC0580C,
        0xFFB21F66, 0xFF4B7F0E, 0xFF8E44AD, 0xFF2E7D8C
    };
    private static final LruCache<String, Bitmap> cache = new LruCache<>(80);

    public static File dir(Context c) {
        File d = new File(c.getFilesDir(), "avatars");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static File fileFor(Context c, String key) {
        return new File(dir(c), Integer.toHexString(key.hashCode()) + ".png");
    }

    public static boolean exists(Context c, String key) {
        return fileFor(c, key).exists();
    }

    public static Bitmap toBitmap(Drawable d) {
        if (d instanceof BitmapDrawable && ((BitmapDrawable) d).getBitmap() != null) {
            return ((BitmapDrawable) d).getBitmap();
        }
        int w = Math.max(1, d.getIntrinsicWidth());
        int h = Math.max(1, d.getIntrinsicHeight());
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        d.setBounds(0, 0, w, h);
        d.draw(cv);
        return b;
    }

    public static void save(Context c, String key, Bitmap src) {
        try {
            Bitmap s = Bitmap.createScaledBitmap(src, 128, 128, true);
            try (FileOutputStream o = new FileOutputStream(fileFor(c, key))) {
                s.compress(Bitmap.CompressFormat.PNG, 100, o);
            }
        } catch (Exception ignored) {}
    }

    public static Bitmap get(Context c, String key, String title, int px) {
        File f = fileFor(c, key);
        String ck = key + "|" + (f.exists() ? f.lastModified() : 0) + "|" + px + "|" + title;
        Bitmap b = cache.get(ck);
        if (b != null) return b;
        if (f.exists()) {
            Bitmap src = BitmapFactory.decodeFile(f.getPath());
            if (src != null) b = circle(src, px);
        }
        if (b == null) b = initial(title, px);
        cache.put(ck, b);
        return b;
    }

    private static Bitmap circle(Bitmap src, int px) {
        Bitmap scaled = Bitmap.createScaledBitmap(src, px, px, true);
        Bitmap out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        new Canvas(out).drawCircle(px / 2f, px / 2f, px / 2f, p);
        return out;
    }

    private static Bitmap initial(String title, int px) {
        String t = title == null ? "" : title.trim();
        String letter = "?";
        for (int i = 0; i < t.length(); ) {
            int cp = t.codePointAt(i);
            if (Character.isLetterOrDigit(cp)) {
                letter = new String(Character.toChars(cp)).toUpperCase(Locale.ROOT);
                break;
            }
            i += Character.charCount(cp);
        }
        Bitmap out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(COLORS[Math.abs(t.hashCode()) % COLORS.length]);
        cv.drawCircle(px / 2f, px / 2f, px / 2f, bg);
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(Color.WHITE);
        tp.setTextSize(px * 0.46f);
        tp.setTextAlign(Paint.Align.CENTER);
        float y = px / 2f - (tp.descent() + tp.ascent()) / 2f;
        cv.drawText(letter, px / 2f, y, tp);
        return out;
    }
}
