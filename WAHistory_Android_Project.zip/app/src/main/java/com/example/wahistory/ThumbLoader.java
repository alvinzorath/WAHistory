package com.example.wahistory;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThumbLoader {
    private static final LruCache<String, Bitmap> cache = new LruCache<>(150);
    private static final ExecutorService pool = Executors.newFixedThreadPool(3);
    private static final Handler main = new Handler(Looper.getMainLooper());

    public static void load(final Context c, final Uri uri, final ImageView iv) {
        final String key = uri.toString();
        iv.setTag(key);
        Bitmap b = cache.get(key);
        if (b != null) {
            iv.setImageBitmap(b);
            return;
        }
        iv.setImageDrawable(new ColorDrawable(0xFFDDE3E6));
        pool.execute(new Runnable() {
            @Override public void run() {
                Bitmap t = null;
                try {
                    t = DocumentsContract.getDocumentThumbnail(
                        c.getContentResolver(), uri, new Point(300, 300), null);
                } catch (Throwable ignored) {}
                if (t == null) t = decode(c, uri, 300);
                final Bitmap res = t;
                if (res == null) return;
                cache.put(key, res);
                main.post(new Runnable() {
                    @Override public void run() {
                        if (key.equals(iv.getTag())) iv.setImageBitmap(res);
                    }
                });
            }
        });
    }

    /** Decode gambar (atau frame pertama video) dengan ukuran terbatas. */
    public static Bitmap decode(Context c, Uri uri, int max) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            if (o.outWidth > 0) {
                int sample = 1;
                while (Math.max(o.outWidth, o.outHeight) / sample > max) sample *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sample;
                try (InputStream in2 = c.getContentResolver().openInputStream(uri)) {
                    return BitmapFactory.decodeStream(in2, null, o2);
                }
            }
        } catch (Throwable ignored) {}
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(c, uri);
            return r.getFrameAtTime(0);
        } catch (Throwable ignored) {
            return null;
        } finally {
            try { r.release(); } catch (Throwable ignored) {}
        }
    }
}
