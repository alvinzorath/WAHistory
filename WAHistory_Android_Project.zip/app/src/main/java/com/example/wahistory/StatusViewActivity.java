package com.example.wahistory;

import android.app.Activity;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class StatusViewActivity extends Activity {
    private Uri uri;
    private boolean video;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_view);

        String u = getIntent().getStringExtra("uri");
        if (u == null) { finish(); return; }
        uri = Uri.parse(u);
        video = getIntent().getBooleanExtra("video", false);
        name = getIntent().getStringExtra("name");
        if (name == null || name.isEmpty()) name = "status_" + System.currentTimeMillis();

        UiUtil.applyInsets(findViewById(R.id.root), findViewById(R.id.header),
            findViewById(R.id.bottomBar));

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnSave).setOnClickListener(v -> save());

        if (video) {
            final VideoView vv = (VideoView) findViewById(R.id.statusVideo);
            vv.setVisibility(View.VISIBLE);
            MediaController mc = new MediaController(this);
            mc.setAnchorView(vv);
            vv.setMediaController(mc);
            vv.setVideoURI(uri);
            vv.setOnPreparedListener(mp -> {
                mp.setLooping(true);
                vv.start();
            });
        } else {
            final ImageView iv = (ImageView) findViewById(R.id.statusImage);
            iv.setVisibility(View.VISIBLE);
            new Thread(() -> {
                final Bitmap b = ThumbLoader.decode(this, uri, 1600);
                runOnUiThread(() -> { if (b != null) iv.setImageBitmap(b); });
            }).start();
        }
    }

    private void save() {
        final String shownName = "Status_" + name;
        new Thread(() -> {
            String result;
            try {
                result = copyOut(shownName);
            } catch (Throwable t) {
                result = "Gagal menyimpan.";
            }
            final String msg = result;
            runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
        }).start();
    }

    private String copyOut(String fileName) throws Exception {
        String mime = video ? "video/mp4" : "image/jpeg";
        String lower = fileName.toLowerCase();
        if (lower.endsWith(".png")) mime = "image/png";
        else if (lower.endsWith(".webp")) mime = "image/webp";
        else if (lower.endsWith(".3gp")) mime = "video/3gpp";

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            String base = video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES;
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, base + "/ArsipWA");
            Uri col = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                            : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            Uri out = getContentResolver().insert(col, cv);
            if (out == null) throw new Exception("insert gagal");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream os = getContentResolver().openOutputStream(out)) {
                copy(in, os);
            }
            return "Tersimpan di " + (video ? "Movies" : "Pictures") + "/ArsipWA";
        }

        File dir = new File(getExternalFilesDir(null), "Status");
        if (!dir.exists()) dir.mkdirs();
        File f = new File(dir, fileName);
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream os = new FileOutputStream(f)) {
            copy(in, os);
        }
        return "Tersimpan di " + f.getAbsolutePath();
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.flush();
    }
}
