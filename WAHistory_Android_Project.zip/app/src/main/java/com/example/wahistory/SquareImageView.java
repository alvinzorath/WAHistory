package com.example.wahistory;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

public class SquareImageView extends ImageView {
    public SquareImageView(Context c) { super(c); }
    public SquareImageView(Context c, AttributeSet a) { super(c, a); }
    public SquareImageView(Context c, AttributeSet a, int d) { super(c, a, d); }

    @Override
    protected void onMeasure(int w, int h) {
        super.onMeasure(w, w);
        setMeasuredDimension(getMeasuredWidth(), getMeasuredWidth());
    }
}
