package com.example.wahistory;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

/** Memberi tahu pengguna saat sebuah pesan dihapus pengirimnya. */
public class Notifier {
    private static final String CHANNEL = "deleted";

    public static void deleted(Context c, String chat, String sender, String text) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(
                    Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            NotificationManager nm =
                (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Pesan dihapus", NotificationManager.IMPORTANCE_DEFAULT));
            PendingIntent pi = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            String who = (sender != null && !sender.isEmpty() && !sender.equals(chat))
                ? sender + " di " + chat : chat;
            Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(who + " menghapus pesan")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
            nm.notify((int) (System.nanoTime() & 0x7fffffff), n);
        } catch (Throwable ignored) {}
    }
}
