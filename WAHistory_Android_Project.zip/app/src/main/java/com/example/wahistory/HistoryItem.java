package com.example.wahistory;

public class HistoryItem {
    public String sender;
    public String message;
    public long time;

    public HistoryItem(String sender, String message, long time) {
        this.sender = sender;
        this.message = message;
        this.time = time;
    }
}
