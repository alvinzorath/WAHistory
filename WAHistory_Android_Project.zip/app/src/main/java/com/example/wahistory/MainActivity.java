package com.example.wahistory;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private HistoryStore store;
    private HistoryAdapter adapter;
    private EditText searchBox;
    private TextView statusText;
    private List<HistoryItem> allItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        store = new HistoryStore(this);
        adapter = new HistoryAdapter(this);

        ListView list = findViewById(R.id.historyList);
        list.setAdapter(adapter);

        searchBox = findViewById(R.id.searchBox);
        statusText = findViewById(R.id.statusText);
        Button accessButton = findViewById(R.id.accessButton);
        Button clearButton = findViewById(R.id.clearButton);

        accessButton.setOnClickListener(v -> {
            try {
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });

        clearButton.setOnClickListener(v -> {
            store.clear();
            loadHistory();
            Toast.makeText(this, "Riwayat dihapus.", Toast.LENGTH_SHORT).show();
        });

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                filter(s.toString());
            }
            @Override public void afterTextChanged(Editable e) {}
        });

        loadHistory();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateAccessStatus();
        loadHistory();
    }

    private void loadHistory() {
        allItems = store.getAll();
        filter(searchBox == null ? "" : searchBox.getText().toString());
    }

    private void filter(String query) {
        String q = query == null ? "" : query.toLowerCase().trim();
        List<HistoryItem> filtered = new ArrayList<>();

        for (HistoryItem item : allItems) {
            if (q.isEmpty()
                || item.sender.toLowerCase().contains(q)
                || item.message.toLowerCase().contains(q)) {
                filtered.add(item);
            }
        }

        adapter.setItems(filtered);
    }

    private void updateAccessStatus() {
        boolean enabled = false;
        try {
            String enabledPackages = android.provider.Settings.Secure.getString(
                getContentResolver(),
                "enabled_notification_listeners"
            );
            enabled = enabledPackages != null &&
                enabledPackages.contains(getPackageName());
        } catch (Exception ignored) {}

        statusText.setText(enabled
            ? "✓ Akses notifikasi aktif"
            : "Akses notifikasi belum diaktifkan.");
    }
}
