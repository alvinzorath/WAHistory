package com.example.wahistory;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.os.Bundle;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements MessageStore.Listener {
    private MessageStore store;
    private ChatListAdapter adapter;
    private View titleRow, searchRow, banner;
    private EditText searchBox;
    private ListView list;
    private TextView empty, promptText, tabChatText, tabStatusText, tabCallsText;
    private View tabChatLine, tabStatusLine, tabCallsLine, statusPrompt;
    private GridView statusGrid;
    private StatusGridAdapter statusAdapter;
    private List<StatusRepo.Item> statusItems;
    private boolean statusFailed;
    private static final int REQ_TREE = 11;
    private static final int REQ_NOTIF = 12;
    private static final int REQ_STORAGE = 13;
    private boolean statusLoaded;
    private AlertDialog setupDialog;
    private int tab = 0; // 0 chat, 1 status, 2 panggilan
    private String query = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        store = MessageStore.get(this);
        adapter = new ChatListAdapter(this);

        UiUtil.applyInsets(findViewById(R.id.root), findViewById(R.id.header),
            findViewById(R.id.content));

        titleRow = findViewById(R.id.titleRow);
        searchRow = findViewById(R.id.searchRow);
        banner = findViewById(R.id.banner);
        searchBox = (EditText) findViewById(R.id.searchBox);
        list = (ListView) findViewById(R.id.list);
        empty = (TextView) findViewById(R.id.empty);
        tabChatText = (TextView) findViewById(R.id.tabChatText);
        tabStatusText = (TextView) findViewById(R.id.tabStatusText);
        tabCallsText = (TextView) findViewById(R.id.tabCallsText);
        tabChatLine = findViewById(R.id.tabChatLine);
        tabStatusLine = findViewById(R.id.tabStatusLine);
        tabCallsLine = findViewById(R.id.tabCallsLine);
        statusGrid = (GridView) findViewById(R.id.statusGrid);
        statusPrompt = findViewById(R.id.statusPrompt);
        promptText = (TextView) findViewById(R.id.promptText);
        statusAdapter = new StatusGridAdapter(this);
        statusGrid.setAdapter(statusAdapter);
        statusGrid.setOnItemClickListener((parent, view, pos, id) -> {
            if (statusItems == null || pos >= statusItems.size()) return;
            StatusRepo.Item it = statusItems.get(pos);
            Intent i = new Intent(this, StatusViewActivity.class);
            i.putExtra("uri", it.uri.toString());
            i.putExtra("video", it.video);
            i.putExtra("name", it.name);
            startActivity(i);
        });
        findViewById(R.id.btnPickStatus).setOnClickListener(v ->
            new AlertDialog.Builder(this)
                .setTitle("Pilih folder manual")
                .setMessage(PROMPT)
                .setPositiveButton("Pilih folder", (d, w) -> pickStatusFolder())
                .setNegativeButton("Batal", null)
                .show());
        findViewById(R.id.btnGrantStorage).setOnClickListener(v -> requestStorage());

        list.setAdapter(adapter);

        findViewById(R.id.tabChat).setOnClickListener(v -> setTab(0));
        findViewById(R.id.tabStatus).setOnClickListener(v -> setTab(1));
        findViewById(R.id.tabCalls).setOnClickListener(v -> setTab(2));
        banner.setOnClickListener(v -> showAccessDialog());
        findViewById(R.id.btnSearch).setOnClickListener(v -> openSearch());
        findViewById(R.id.btnSearchBack).setOnClickListener(v -> closeSearch());
        findViewById(R.id.btnMore).setOnClickListener(v -> showMenu(v));

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                query = s.toString();
                refresh();
            }
            @Override public void afterTextChanged(Editable e) {}
        });

        list.setOnItemClickListener((parent, view, pos, id) -> {
            if (tab != 0) return;
            ChatListAdapter.Row r = (ChatListAdapter.Row) adapter.getItem(pos);
            Intent i = new Intent(this, ChatActivity.class);
            i.putExtra("key", r.key);
            i.putExtra("title", r.title);
            i.putExtra("group", r.group);
            startActivity(i);
        });

        list.setOnItemLongClickListener((parent, view, pos, id) -> {
            if (tab != 0) return false;
            final ChatListAdapter.Row r = (ChatListAdapter.Row) adapter.getItem(pos);
            new AlertDialog.Builder(this)
                .setMessage("Hapus semua pesan tersimpan dari \"" + r.title + "\"?")
                .setPositiveButton("Hapus", (d, w) -> store.deleteChat(r.key))
                .setNegativeButton("Batal", null)
                .show();
            return true;
        });

        setTab(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        store.setListener(this);
        boolean access = accessEnabled();
        banner.setVisibility(access ? View.GONE : View.VISIBLE);
        if (access) syncListener();
        if (tab == 1) reloadStatus();
        refresh();
        runSetup();
    }

    @Override
    protected void onPause() {
        super.onPause();
        store.setListener(null);
    }

    @Override
    public void onChanged() { refresh(); }

    @Override
    public void onBackPressed() {
        if (searchRow.getVisibility() == View.VISIBLE) closeSearch();
        else super.onBackPressed();
    }

    /** Pastikan listener terhubung dan ambil pesan dari notifikasi yang masih tampil. */
    private void syncListener() {
        final WhatsAppNotificationListener inst = WhatsAppNotificationListener.instance;
        if (inst != null) {
            new Thread(() -> inst.syncActive()).start();
        } else {
            try {
                NotificationListenerService.requestRebind(
                    new ComponentName(this, WhatsAppNotificationListener.class));
                DebugLog.add("listener belum terhubung, minta sambung");
            } catch (Throwable ignored) {}
        }
    }

    private void showDiagnostics() {
        boolean connected = WhatsAppNotificationListener.instance != null;
        String msg = "Listener terhubung: " + (connected ? "ya" : "TIDAK")
            + "\nAkses notifikasi: " + (accessEnabled() ? "aktif" : "belum aktif")
            + "\nPesan tersimpan: " + store.size()
            + "\n\nKejadian terbaru (isi pesan tidak dicatat):\n" + DebugLog.dump();
        new AlertDialog.Builder(this)
            .setTitle("Diagnostik")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show();
    }

    private boolean accessEnabled() {
        try {
            String s = Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners");
            return s != null && s.contains(getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    private void setTab(int t) {
        tab = t;
        tabChatText.setTextColor(t == 0 ? 0xFFFFFFFF : 0xB3FFFFFF);
        tabStatusText.setTextColor(t == 1 ? 0xFFFFFFFF : 0xB3FFFFFF);
        tabCallsText.setTextColor(t == 2 ? 0xFFFFFFFF : 0xB3FFFFFF);
        tabChatLine.setBackgroundColor(t == 0 ? 0xFFFFFFFF : 0x00000000);
        tabStatusLine.setBackgroundColor(t == 1 ? 0xFFFFFFFF : 0x00000000);
        tabCallsLine.setBackgroundColor(t == 2 ? 0xFFFFFFFF : 0x00000000);
        if (t == 1) reloadStatus();
        refresh();
    }

    private void refresh() {
        list.setVisibility(tab == 1 ? View.GONE : View.VISIBLE);
        statusGrid.setVisibility(View.GONE);
        statusPrompt.setVisibility(View.GONE);
        empty.setVisibility(View.GONE);
        if (tab == 1) {
            showStatus();
            return;
        }
        List<ChatListAdapter.Row> rows = new ArrayList<>();
        if (tab == 0) {
            for (Chat c : store.getChats(query)) {
                Msg m = c.match != null ? c.match : c.last;
                ChatListAdapter.Row r = new ChatListAdapter.Row();
                r.key = c.key;
                r.title = c.title;
                r.group = c.group;
                r.time = m.time;
                String prefix = (c.group && m.sender != null && !m.sender.isEmpty())
                    ? m.sender + ": " : "";
                r.preview = (m.deleted ? "\uD83D\uDEAB " : "") + prefix + m.text.replace('\n', ' ');
                r.red = m.deleted;
                rows.add(r);
            }
        } else {
            for (Msg m : store.getCalls(query)) {
                ChatListAdapter.Row r = new ChatListAdapter.Row();
                r.key = m.chatKey;
                r.title = m.chat;
                r.group = m.group;
                r.time = m.time;
                r.preview = m.text;
                r.red = MessageStore.isMissed(m.text);
                rows.add(r);
            }
        }
        adapter.setRows(rows);

        if (rows.isEmpty()) {
            if (!query.trim().isEmpty()) {
                empty.setText("Tidak ada hasil untuk \"" + query.trim() + "\"");
            } else if (tab == 0) {
                empty.setText("Belum ada pesan tersimpan.\n\nPesan WhatsApp yang masuk akan muncul di sini setelah akses notifikasi diaktifkan.");
            } else {
                empty.setText("Belum ada panggilan tercatat.\n\nPanggilan masuk dan tak terjawab akan muncul di sini.");
            }
            empty.setVisibility(View.VISIBLE);
        } else {
            empty.setVisibility(View.GONE);
        }
    }

    private static final String PROMPT =
        "Untuk melihat dan menyimpan status teman, izinkan akses ke folder status WhatsApp.\n\n"
        + "1. Ketuk tombol di bawah.\n"
        + "2. Buka Android > media > com.whatsapp > WhatsApp > Media > .Statuses "
        + "(WhatsApp Business: com.whatsapp.w4b).\n"
        + "3. Ketuk \"Gunakan folder ini\", lalu \"Izinkan\".\n\n"
        + "Status baru muncul setelah kamu melihatnya di WhatsApp.";

    private String savedTree() {
        return getSharedPreferences("settings", MODE_PRIVATE).getString("status_tree", null);
    }

    private void pickStatusFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        try {
            Uri init = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents",
                "primary:Android/media/com.whatsapp/WhatsApp/Media/.Statuses");
            i.putExtra(DocumentsContract.EXTRA_INITIAL_URI, init);
        } catch (Exception ignored) {}
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        try {
            startActivityForResult(i, REQ_TREE);
        } catch (Exception e) {
            Toast.makeText(this, "Pemilih folder tidak tersedia di HP ini.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_TREE && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(u,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            getSharedPreferences("settings", MODE_PRIVATE).edit()
                .putString("status_tree", u.toString()).apply();
            statusItems = null;
            statusFailed = false;
            statusLoaded = false;
            setTab(1);
        }
    }

    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasNotifPermission() {
        return Build.VERSION.SDK_INT < 33 || checkSelfPermission(
            Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception ignored) {}
            }
        } else {
            requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_STORAGE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (tab == 1) reloadStatus();
        runSetup();
    }

    /** Minta izin satu per satu saat pertama kali dibuka (tiap langkah hanya sekali otomatis). */
    private void runSetup() {
        if (setupDialog != null && setupDialog.isShowing()) return;
        SharedPreferences sp = getSharedPreferences("settings", MODE_PRIVATE);

        if (!accessEnabled() && !sp.getBoolean("asked_listener", false)) {
            sp.edit().putBoolean("asked_listener", true).apply();
            setupDialog = showAccessDialog(true);
            return;
        }
        if (!hasNotifPermission() && !sp.getBoolean("asked_notif", false)) {
            sp.edit().putBoolean("asked_notif", true).apply();
            requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        if (!hasStorageAccess() && !sp.getBoolean("asked_storage", false)) {
            sp.edit().putBoolean("asked_storage", true).apply();
            setupDialog = new AlertDialog.Builder(this)
                .setTitle("Izin akses file")
                .setMessage("Agar status WhatsApp bisa diambil otomatis tanpa memilih folder, "
                    + "aplikasi perlu izin \"Akses semua file\". Ketuk Izinkan, lalu aktifkan "
                    + "\"Arsip WA\" di halaman berikutnya.")
                .setPositiveButton("Izinkan", (d, w) -> requestStorage())
                .setNegativeButton("Nanti", null)
                .show();
        }
    }

    private void reloadStatus() {
        final String saved = savedTree();
        new Thread(() -> {
            List<StatusRepo.Item> res = null;
            if (hasStorageAccess()) res = StatusRepo.loadAuto();
            if (res == null && saved != null) res = StatusRepo.safeLoad(this, Uri.parse(saved));
            final List<StatusRepo.Item> out = res;
            runOnUiThread(() -> {
                statusItems = out;
                statusLoaded = true;
                if (tab == 1) showStatus();
            });
        }).start();
    }

    private void showStatus() {
        statusGrid.setVisibility(View.GONE);
        statusPrompt.setVisibility(View.GONE);
        empty.setVisibility(View.GONE);
        if (!statusLoaded) {
            empty.setText("Memuat status...");
            empty.setVisibility(View.VISIBLE);
            return;
        }
        if (statusItems == null) {
            boolean access = hasStorageAccess();
            promptText.setText(access
                ? "Folder status WhatsApp tidak ditemukan.\n\nPastikan WhatsApp terpasang dan kamu sudah pernah melihat status teman. Atau pilih folder secara manual."
                : "Aplikasi perlu izin \"Akses semua file\" supaya status WhatsApp bisa diambil otomatis.");
            findViewById(R.id.btnGrantStorage).setVisibility(access ? View.GONE : View.VISIBLE);
            statusPrompt.setVisibility(View.VISIBLE);
            return;
        }
        if (statusItems.isEmpty()) {
            empty.setText("Belum ada status.\n\nBuka dan lihat status teman di WhatsApp dulu, lalu kembali ke sini.");
            empty.setVisibility(View.VISIBLE);
            return;
        }
        statusAdapter.set(statusItems);
        statusGrid.setVisibility(View.VISIBLE);
    }

    private void openSearch() {
        titleRow.setVisibility(View.GONE);
        searchRow.setVisibility(View.VISIBLE);
        searchBox.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(searchBox, 0);
    }

    private void closeSearch() {
        searchBox.setText("");
        searchRow.setVisibility(View.GONE);
        titleRow.setVisibility(View.VISIBLE);
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
    }

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, "Akses notifikasi");
        pm.getMenu().add(0, 2, 1, "Agar tidak berhenti sendiri");
        pm.getMenu().add(0, 6, 2, "Diagnostik pesan terlewat");
        pm.getMenu().add(0, 5, 2, "Ganti folder Status");
        pm.getMenu().add(0, 3, 3, "Hapus semua riwayat");
        pm.getMenu().add(0, 4, 4, "Tentang");
        pm.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: showAccessDialog(); break;
                case 2: showKeepAliveDialog(); break;
                case 5: pickStatusFolder(); break;
                case 6: showDiagnostics(); break;
                case 3: confirmClearAll(); break;
                case 4: showAbout(); break;
            }
            return true;
        });
        pm.show();
    }

    private void showAccessDialog() { showAccessDialog(false); }

    private AlertDialog showAccessDialog(final boolean chain) {
        return new AlertDialog.Builder(this)
            .setTitle("Aktifkan akses notifikasi")
            .setMessage("1. Ketuk \"Buka pengaturan\", lalu aktifkan \"Arsip WA\".\n\n"
                + "2. Jika tombolnya abu-abu atau muncul \"Setelan terbatas\" (Android 13 ke atas): "
                + "ketuk \"Info aplikasi\", tekan titik tiga di kanan atas, pilih "
                + "\"Izinkan setelan terbatas\", lalu ulangi langkah 1.")
            .setPositiveButton("Buka pengaturan", (d, w) -> {
                try {
                    startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            })
            .setNeutralButton("Info aplikasi", (d, w) -> {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            })
            .setNegativeButton("Tutup", (d, w) -> { if (chain) runSetup(); })
            .show();
    }

    private void showKeepAliveDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Agar tidak berhenti sendiri")
            .setMessage("Beberapa HP (Xiaomi, Oppo, Vivo, Samsung, dll) mematikan aplikasi di latar belakang, "
                + "sehingga pesan tidak tersimpan. Atur:\n\n"
                + "• Info aplikasi, Penghemat baterai: pilih \"Tanpa batasan\".\n"
                + "• Aktifkan \"Mulai otomatis\" / \"Autostart\" bila ada.\n"
                + "• Di layar aplikasi terbaru, kunci aplikasi ini (ikon gembok).")
            .setPositiveButton("Info aplikasi", (d, w) -> {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            })
            .setNegativeButton("Tutup", null)
            .show();
    }

    private void confirmClearAll() {
        new AlertDialog.Builder(this)
            .setMessage("Hapus semua riwayat yang tersimpan? Ini tidak bisa dibatalkan.")
            .setPositiveButton("Hapus", (d, w) -> {
                store.clearAll();
                Toast.makeText(this, "Riwayat dihapus.", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
            .setTitle("Arsip WA")
            .setMessage("Menyimpan notifikasi WhatsApp yang masuk ke HP ini. Semua data hanya "
                + "disimpan di perangkat, tanpa server.\n\n"
                + "Pesan yang dihapus pengirim ditandai merah, selama pesannya sudah sempat "
                + "masuk lewat notifikasi sebelum dihapus.\n\n"
                + "Batasan: hanya pesan masuk yang tampil di notifikasi. Pesan yang kamu kirim "
                + "dan isi media pesan tidak tersedia.")
            .setPositiveButton("OK", null)
            .show();
    }
}
