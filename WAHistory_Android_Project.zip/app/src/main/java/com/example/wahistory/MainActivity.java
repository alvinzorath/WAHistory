package com.example.wahistory;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements MessageStore.Listener {
    private MessageStore store;
    private ChatListAdapter adapter;
    private View titleRow, searchRow, banner;
    private EditText searchBox;
    private ListView list;
    private TextView empty, tabChatText, tabCallsText;
    private View tabChatLine, tabCallsLine;
    private int tab = 0;
    private String query = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        store = MessageStore.get(this);
        adapter = new ChatListAdapter(this);

        UiUtil.applyInsets(findViewById(R.id.root), findViewById(R.id.header),
            findViewById(R.id.content));

        titleRow = findViewById(R.id.titleRow);
        searchRow = findViewById(R.id.searchRow);
        banner = findViewById(R.id.banner);
        searchBox = (EditText) findViewById(R.id.searchBox);
        list = (ListView) findViewById(R.id.list);
        empty = (TextView) findViewById(R.id.empty);
        tabChatText = (TextView) findViewById(R.id.tabChatText);
        tabCallsText = (TextView) findViewById(R.id.tabCallsText);
        tabChatLine = findViewById(R.id.tabChatLine);
        tabCallsLine = findViewById(R.id.tabCallsLine);

        list.setAdapter(adapter);

        findViewById(R.id.tabChat).setOnClickListener(v -> setTab(0));
        findViewById(R.id.tabCalls).setOnClickListener(v -> setTab(1));
        banner.setOnClickListener(v -> showAccessDialog());
        findViewById(R.id.btnSearch).setOnClickListener(v -> openSearch());
        findViewById(R.id.btnSearchBack).setOnClickListener(v -> closeSearch());
        findViewById(R.id.btnMore).setOnClickListener(v -> showMenu(v));

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                query = s.toString();
                refresh();
            }
            @Override public void afterTextChanged(Editable e) {}
        });

        list.setOnItemClickListener((parent, view, pos, id) -> {
            if (tab != 0) return;
            ChatListAdapter.Row r = (ChatListAdapter.Row) adapter.getItem(pos);
            Intent i = new Intent(this, ChatActivity.class);
            i.putExtra("key", r.key);
            i.putExtra("title", r.title);
            i.putExtra("group", r.group);
            startActivity(i);
        });

        list.setOnItemLongClickListener((parent, view, pos, id) -> {
            if (tab != 0) return false;
            final ChatListAdapter.Row r = (ChatListAdapter.Row) adapter.getItem(pos);
            new AlertDialog.Builder(this)
                .setMessage("Hapus semua pesan tersimpan dari \"" + r.title + "\"?")
                .setPositiveButton("Hapus", (d, w) -> store.deleteChat(r.key))
                .setNegativeButton("Batal", null)
                .show();
            return true;
        });

        setTab(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        store.setListener(this);
        banner.setVisibility(accessEnabled() ? View.GONE : View.VISIBLE);
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        store.setListener(null);
    }

    @Override
    public void onChanged() { refresh(); }

    @Override
    public void onBackPressed() {
        if (searchRow.getVisibility() == View.VISIBLE) closeSearch();
        else super.onBackPressed();
    }

    private boolean accessEnabled() {
        try {
            String s = Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners");
            return s != null && s.contains(getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    private void setTab(int t) {
        tab = t;
        tabChatText.setTextColor(t == 0 ? 0xFFFFFFFF : 0xB3FFFFFF);
        tabCallsText.setTextColor(t == 1 ? 0xFFFFFFFF : 0xB3FFFFFF);
        tabChatLine.setBackgroundColor(t == 0 ? 0xFFFFFFFF : 0x00000000);
        tabCallsLine.setBackgroundColor(t == 1 ? 0xFFFFFFFF : 0x00000000);
        refresh();
    }

    private void refresh() {
        List<ChatListAdapter.Row> rows = new ArrayList<>();
        if (tab == 0) {
            for (Chat c : store.getChats(query)) {
                Msg m = c.match != null ? c.match : c.last;
                ChatListAdapter.Row r = new ChatListAdapter.Row();
                r.key = c.key;
                r.title = c.title;
                r.group = c.group;
                r.time = m.time;
                String prefix = (c.group && m.sender != null && !m.sender.isEmpty())
                    ? m.sender + ": " : "";
                r.preview = prefix + m.text.replace('\n', ' ');
                rows.add(r);
            }
        } else {
            for (Msg m : store.getCalls(query)) {
                ChatListAdapter.Row r = new ChatListAdapter.Row();
                r.key = m.chatKey;
                r.title = m.chat;
                r.group = m.group;
                r.time = m.time;
                r.preview = m.text;
                r.red = MessageStore.isMissed(m.text);
                rows.add(r);
            }
        }
        adapter.setRows(rows);

        if (rows.isEmpty()) {
            if (!query.trim().isEmpty()) {
                empty.setText("Tidak ada hasil untuk \"" + query.trim() + "\"");
            } else if (tab == 0) {
                empty.setText("Belum ada pesan tersimpan.\n\nPesan WhatsApp yang masuk akan muncul di sini setelah akses notifikasi diaktifkan.");
            } else {
                empty.setText("Belum ada panggilan tercatat.\n\nPanggilan masuk dan tak terjawab akan muncul di sini.");
            }
            empty.setVisibility(View.VISIBLE);
        } else {
            empty.setVisibility(View.GONE);
        }
    }

    private void openSearch() {
        titleRow.setVisibility(View.GONE);
        searchRow.setVisibility(View.VISIBLE);
        searchBox.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(searchBox, 0);
    }

    private void closeSearch() {
        searchBox.setText("");
        searchRow.setVisibility(View.GONE);
        titleRow.setVisibility(View.VISIBLE);
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
    }

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, "Akses notifikasi");
        pm.getMenu().add(0, 2, 1, "Agar tidak berhenti sendiri");
        pm.getMenu().add(0, 3, 2, "Hapus semua riwayat");
        pm.getMenu().add(0, 4, 3, "Tentang");
        pm.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: showAccessDialog(); break;
                case 2: showKeepAliveDialog(); break;
                case 3: confirmClearAll(); break;
                case 4: showAbout(); break;
            }
            return true;
        });
        pm.show();
    }

    private void showAccessDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Aktifkan akses notifikasi")
            .setMessage("1. Ketuk \"Buka pengaturan\", lalu aktifkan \"Arsip WA\".\n\n"
                + "2. Jika tombolnya abu-abu atau muncul \"Setelan terbatas\" (Android 13 ke atas): "
                + "ketuk \"Info aplikasi\", tekan titik tiga di kanan atas, pilih "
                + "\"Izinkan setelan terbatas\", lalu ulangi langkah 1.")
            .setPositiveButton("Buka pengaturan", (d, w) -> {
                try {
                    startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            })
            .setNeutralButton("Info aplikasi", (d, w) -> {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            })
            .setNegativeButton("Tutup", null)
            .show();
    }

    private void showKeepAliveDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Agar tidak berhenti sendiri")
            .setMessage("Beberapa HP (Xiaomi, Oppo, Vivo, Samsung, dll) mematikan aplikasi di latar belakang, "
                + "sehingga pesan tidak tersimpan. Atur:\n\n"
                + "• Info aplikasi, Penghemat baterai: pilih \"Tanpa batasan\".\n"
                + "• Aktifkan \"Mulai otomatis\" / \"Autostart\" bila ada.\n"
                + "• Di layar aplikasi terbaru, kunci aplikasi ini (ikon gembok).")
            .setPositiveButton("Info aplikasi", (d, w) -> {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            })
            .setNegativeButton("Tutup", null)
            .show();
    }

    private void confirmClearAll() {
        new AlertDialog.Builder(this)
            .setMessage("Hapus semua riwayat yang tersimpan? Ini tidak bisa dibatalkan.")
            .setPositiveButton("Hapus", (d, w) -> {
                store.clearAll();
                Toast.makeText(this, "Riwayat dihapus.", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
            .setTitle("Arsip WA")
            .setMessage("Menyimpan notifikasi WhatsApp yang masuk ke HP ini. Semua data hanya "
                + "disimpan di perangkat, tanpa server.\n\n"
                + "Batasan: hanya pesan masuk yang tampil di notifikasi. Pesan yang kamu kirim, "
                + "status, dan isi media (foto/video) tidak tersedia lewat notifikasi.")
            .setPositiveButton("OK", null)
            .show();
    }
}
