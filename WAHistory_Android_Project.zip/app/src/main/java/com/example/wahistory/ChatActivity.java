package com.example.wahistory;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends Activity implements MessageStore.Listener {
    private static final int[] SENDER_COLORS = {
        0xFFB21F66, 0xFF1F7AB2, 0xFF6A5ACD, 0xFFC0580C,
        0xFF128C7E, 0xFF9B2C2C, 0xFF4B7F0E, 0xFF8E44AD
    };

    private MessageStore store;
    private String key, title;
    private boolean group;
    private ListView list;
    private MsgAdapter adapter;
    private TextView subtitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        key = getIntent().getStringExtra("key");
        title = getIntent().getStringExtra("title");
        group = getIntent().getBooleanExtra("group", false);
        if (key == null) { finish(); return; }
        if (title == null) title = "";

        store = MessageStore.get(this);
        UiUtil.applyInsets(findViewById(R.id.root), findViewById(R.id.header),
            findViewById(R.id.content));

        ((TextView) findViewById(R.id.title)).setText(title);
        subtitle = (TextView) findViewById(R.id.subtitle);
        ((ImageView) findViewById(R.id.avatar)).setImageBitmap(
            Avatars.get(this, key, title, UiUtil.dp(this, 40)));

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnMore).setOnClickListener(v -> {
            PopupMenu pm = new PopupMenu(this, v);
            pm.getMenu().add(0, 1, 0, "Hapus chat ini");
            pm.setOnMenuItemClickListener(item -> { confirmDelete(); return true; });
            pm.show();
        });

        list = (ListView) findViewById(R.id.msgList);
        adapter = new MsgAdapter();
        list.setAdapter(adapter);
        list.setOnItemLongClickListener((parent, view, pos, id) -> {
            Object o = adapter.getItem(pos);
            if (o instanceof Msg) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("pesan", ((Msg) o).text));
                    Toast.makeText(this, "Pesan disalin", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            return false;
        });

        load(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (store != null) store.setListener(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (store != null) store.setListener(null);
    }

    @Override
    public void onChanged() { load(false); }

    private void load(boolean forceBottom) {
        List<Msg> msgs = store.getMessages(key);
        if (msgs.isEmpty() && !forceBottom) { finish(); return; }

        boolean atBottom = forceBottom
            || list.getLastVisiblePosition() >= adapter.getCount() - 2;

        List<Object> items = new ArrayList<>();
        long prev = 0;
        for (Msg m : msgs) {
            if (prev == 0 || !UiUtil.sameDay(prev, m.time)) items.add(UiUtil.dayLabel(m.time));
            items.add(m);
            prev = m.time;
        }
        adapter.set(items);
        subtitle.setText((group ? "Grup \u00B7 " : "") + msgs.size() + " pesan tersimpan");
        if (atBottom && !items.isEmpty()) list.setSelection(items.size() - 1);
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
            .setMessage("Hapus semua pesan tersimpan dari \"" + title + "\"?")
            .setPositiveButton("Hapus", (d, w) -> {
                store.deleteChat(key);
                finish();
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    private class MsgAdapter extends BaseAdapter {
        private List<Object> items = new ArrayList<>();

        void set(List<Object> n) {
            items = new ArrayList<>(n);
            notifyDataSetChanged();
        }

        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int p) { return items.get(p); }
        @Override public long getItemId(int p) { return p; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int p) { return items.get(p) instanceof String ? 0 : 1; }
        @Override public boolean isEnabled(int p) { return false; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Object o = items.get(position);
            LayoutInflater inf = LayoutInflater.from(ChatActivity.this);
            if (o instanceof String) {
                View v = convertView != null ? convertView
                    : inf.inflate(R.layout.item_date, parent, false);
                ((TextView) v.findViewById(R.id.dateText)).setText((String) o);
                return v;
            }
            View v = convertView != null ? convertView
                : inf.inflate(R.layout.item_msg, parent, false);
            Msg m = (Msg) o;
            TextView sender = (TextView) v.findViewById(R.id.sender);
            if (group && m.sender != null && !m.sender.isEmpty()) {
                sender.setText(m.sender);
                sender.setTextColor(SENDER_COLORS[Math.abs(m.sender.hashCode()) % SENDER_COLORS.length]);
                sender.setVisibility(View.VISIBLE);
            } else {
                sender.setVisibility(View.GONE);
            }
            v.findViewById(R.id.bubble).setBackgroundResource(
                m.deleted ? R.drawable.bg_bubble_deleted : R.drawable.bg_bubble_in);
            v.findViewById(R.id.deletedLabel).setVisibility(m.deleted ? View.VISIBLE : View.GONE);
            ((TextView) v.findViewById(R.id.text)).setText(m.text);
            ((TextView) v.findViewById(R.id.time)).setText(UiUtil.clock(m.time));
            return v;
        }
    }
}
