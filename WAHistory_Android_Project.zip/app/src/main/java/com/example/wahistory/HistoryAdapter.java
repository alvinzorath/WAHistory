package com.example.wahistory;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HistoryAdapter extends BaseAdapter {
    private final Context context;
    private List<HistoryItem> items = new ArrayList<>();

    public HistoryAdapter(Context context) {
        this.context = context;
    }

    public void setItems(List<HistoryItem> newItems) {
        items = new ArrayList<>(newItems);
        notifyDataSetChanged();
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int position) { return items.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            v = LayoutInflater.from(context).inflate(R.layout.history_item, parent, false);
        }

        HistoryItem item = items.get(position);
        ((TextView) v.findViewById(R.id.sender)).setText(item.sender);
        ((TextView) v.findViewById(R.id.message)).setText(item.message);
        ((TextView) v.findViewById(R.id.time)).setText(
            DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(new Date(item.time))
        );
        return v;
    }
}
