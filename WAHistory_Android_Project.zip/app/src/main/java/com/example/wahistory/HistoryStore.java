package com.example.wahistory;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class HistoryStore {
    private static final String PREF = "history_store";
    private static final String KEY = "items";
    private final SharedPreferences prefs;

    public HistoryStore(Context context) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public synchronized void add(String sender, String message, long time) {
        try {
            JSONArray old = new JSONArray(prefs.getString(KEY, "[]"));
            JSONArray out = new JSONArray();

            JSONObject item = new JSONObject();
            item.put("sender", sender);
            item.put("message", message);
            item.put("time", time);
            out.put(item);

            // Simpan paling banyak 500 notifikasi terbaru.
            int start = Math.max(0, old.length() - 499);
            for (int i = start; i < old.length(); i++) {
                out.put(old.getJSONObject(i));
            }

            prefs.edit().putString(KEY, out.toString()).apply();
        } catch (Exception ignored) {}
    }

    public synchronized List<HistoryItem> getAll() {
        List<HistoryItem> result = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(KEY, "[]"));
            for (int i = arr.length() - 1; i >= 0; i--) {
                JSONObject o = arr.getJSONObject(i);
                result.add(new HistoryItem(
                    o.optString("sender", "WhatsApp"),
                    o.optString("message", ""),
                    o.optLong("time", 0)
                ));
            }
        } catch (Exception ignored) {}
        return result;
    }

    public synchronized void clear() {
        prefs.edit().remove(KEY).apply();
    }
}
