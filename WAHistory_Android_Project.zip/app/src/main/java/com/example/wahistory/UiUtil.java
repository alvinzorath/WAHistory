package com.example.wahistory;

import android.content.Context;
import android.view.View;
import android.view.WindowInsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class UiUtil {
    private static final Locale ID = new Locale("id", "ID");

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    /** Android 15 menggambar app di bawah status/navigation bar; beri ruang di header dan bawah. */
    @SuppressWarnings("deprecation")
    public static void applyInsets(View root, final View header, final View bottomTarget) {
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets ins) {
                header.setPadding(ins.getSystemWindowInsetLeft(), ins.getSystemWindowInsetTop(),
                        ins.getSystemWindowInsetRight(), 0);
                bottomTarget.setPadding(ins.getSystemWindowInsetLeft(), 0,
                        ins.getSystemWindowInsetRight(), ins.getSystemWindowInsetBottom());
                return ins;
            }
        });
    }

    private static long dayNum(long t) {
        return (t + TimeZone.getDefault().getOffset(t)) / 86400000L;
    }

    public static String clock(long t) {
        return new SimpleDateFormat("HH:mm", ID).format(new Date(t));
    }

    /** Waktu di daftar chat: jam / Kemarin / nama hari / tanggal. */
    public static String listTime(long t) {
        long d = dayNum(System.currentTimeMillis()) - dayNum(t);
        if (d <= 0) return clock(t);
        if (d == 1) return "Kemarin";
        if (d < 7) return new SimpleDateFormat("EEEE", ID).format(new Date(t));
        return new SimpleDateFormat("dd/MM/yyyy", ID).format(new Date(t));
    }

    /** Label pemisah tanggal di dalam chat. */
    public static String dayLabel(long t) {
        long d = dayNum(System.currentTimeMillis()) - dayNum(t);
        if (d <= 0) return "Hari ini";
        if (d == 1) return "Kemarin";
        return new SimpleDateFormat("d MMMM yyyy", ID).format(new Date(t));
    }

    public static boolean sameDay(long a, long b) {
        return dayNum(a) == dayNum(b);
    }
}
