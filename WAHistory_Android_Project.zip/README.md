# Arsip WA

Aplikasi Android untuk menyimpan notifikasi WhatsApp di HP sendiri, dengan tampilan mirip WhatsApp.

- Tab Chat: daftar per kontak/grup, foto profil, layar percakapan berbentuk gelembung
- Pesan yang dihapus pengirim ditandai merah (bila sempat masuk lewat notifikasi)
- Tab Status: lihat dan simpan status yang sudah dibuka di WhatsApp (lewat izin folder .Statuses)
- Tab Panggilan: panggilan masuk dan tak terjawab
- Pencarian, hapus per chat, hapus semua. Data hanya di perangkat.
