# WA History

Aplikasi Android sederhana untuk menyimpan riwayat notifikasi WhatsApp pada perangkat sendiri.

Fitur:
- Nama pengirim
- Isi pesan dari notifikasi
- Waktu
- Pencarian
- Hapus semua riwayat
- Penyimpanan lokal (tidak memakai server)

Cara menjalankan:
1. Import folder ini ke AndroidIDE atau Android Studio.
2. Build/Run aplikasi.
3. Buka WA History.
4. Tekan "Aktifkan Akses Notifikasi".
5. Aktifkan WA History pada daftar Notification Access.
6. Kembali ke aplikasi.

Catatan:
- Aplikasi hanya menerima data yang tersedia pada notifikasi Android.
- Jika notifikasi WhatsApp tidak menampilkan isi pesan, aplikasi juga tidak bisa mengambil isi tersebut.
- Foto/video tidak diambil dari database internal WhatsApp.
- Riwayat disimpan lokal di perangkat.
