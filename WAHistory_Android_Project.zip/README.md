# Arsip WA

Aplikasi Android untuk menyimpan riwayat notifikasi WhatsApp di HP sendiri, dengan tampilan mirip WhatsApp.

Fitur:
- Daftar chat per kontak/grup (foto profil dari notifikasi, bila ada)
- Layar percakapan berbentuk gelembung chat, dipisah per tanggal
- Tab Panggilan (masuk dan tidak terjawab)
- Pencarian nama dan isi pesan, hapus per chat, hapus semua
- Penyimpanan lokal, tanpa server

Cara pakai: pasang, buka, ketuk banner kuning, aktifkan "Arsip WA" di Akses Notifikasi.

Batasan: hanya pesan masuk yang tampil di notifikasi. Pesan terkirim, status, dan isi media tidak tersedia.
